﻿using FIgGPV.Models;
using Microsoft.AspNetCore.Mvc;
using FIgGPV.ViewModels;

namespace FIgGPV.Controllers
{
    public class HomeController : Controller
    {
        private readonly IFigRepository _figRepository;

        public HomeController(IFigRepository figRepository)
        {
            _figRepository = figRepository;
        }
        public IActionResult Index()
        {
            var topFigs = _figRepository.TopFigs;
            var homeViewModel = new HomeViewModel(topFigs);
            return View(homeViewModel);
        }
    }
}
