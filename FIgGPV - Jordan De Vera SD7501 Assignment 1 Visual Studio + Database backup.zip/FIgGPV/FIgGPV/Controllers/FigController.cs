﻿using FIgGPV.Models;
using FIgGPV.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.IO.Pipelines;

namespace FIgGPV.Controllers
{
    public class FigController : Controller
    {
        private readonly IFigRepository _figRepository;
        private readonly ICategoryRepository _categoryRepository;

        public FigController(IFigRepository figRepository, ICategoryRepository categoryRepository)
        {
            _figRepository = figRepository;
            _categoryRepository = categoryRepository;
        }

        public ViewResult List(string category)
        {
            IEnumerable<Fig> figs;
            string? currentCategory;

            if (string.IsNullOrEmpty(category))
            {
                figs = _figRepository.AllFigs.OrderBy(p => p.FigId);
                currentCategory = "All Figs";
            }
            else
            {
                figs = _figRepository.AllFigs.Where(p => p.Category.CategoryName == category)
                    .OrderBy(p => p.FigId);
                currentCategory = _categoryRepository.AllCategories.FirstOrDefault(c => c.CategoryName == category)?.CategoryName;
            }
            return View(new FigListViewModel(figs, currentCategory));
        }

        public IActionResult Details(int id)
        {
            var fig = _figRepository.GetFigById(id);
            if (fig == null)
            {
                return NotFound();
            }
            return View(fig);
        }

    }
}
