﻿using FIgGPV.Models;
using Microsoft.AspNetCore.Mvc;
using FIgGPV.ViewModels;

namespace FIgGPV.Controllers
{
    public class ShoppingCartController : Controller
    {
        private readonly IFigRepository _figRepository;
        private readonly IShoppingCart _shoppingCart;

        public ShoppingCartController(IFigRepository figRepository, IShoppingCart shoppingCart)
        {
            _figRepository = figRepository;
            _shoppingCart = shoppingCart;
        }

        public ViewResult Index()
        {
            var items = _shoppingCart.GetShoppingCartItems();
            _shoppingCart.ShoppingCartItems = items;

            var shoppingCartViewModel = new ShoppingCartViewModel(_shoppingCart, _shoppingCart.GetShoppingCartTotal());

            return View(shoppingCartViewModel);
        }

        public RedirectToActionResult AddToShoppingCart(int figId)
        {
            var selectedFig = _figRepository.AllFigs.FirstOrDefault(p => p.FigId == figId);
            if (selectedFig != null)
            {
                _shoppingCart.AddToCart(selectedFig);
            }
            return RedirectToAction("Index");
        }

        public RedirectToActionResult RemoveFromShoppingCart(int figId)
        {
            var selectedFig = _figRepository.AllFigs.FirstOrDefault(p => p.FigId == figId);
            if (selectedFig != null)
            {
                _shoppingCart.RemoveFromCart(selectedFig);
            }
            return RedirectToAction("Index");
        }


    }
}
