﻿using System.IO.Pipelines;

namespace FIgGPV.Models
{
    public class DbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            FIgGPVDbContext context =
                applicationBuilder.ApplicationServices.CreateScope().
                ServiceProvider.GetRequiredService<FIgGPVDbContext>();

            if (!context.Categories.Any())
            {
                context.Categories.AddRange(Categories.Select(c => c.Value));
            }

            if (!context.Figs.Any())
            {
                context.AddRange
                (
                    new  Fig { Name = "Statue of Her Excellency, Narukami Ogosho God of Thunder", Price = 15.95M, ShortDescription = "Lorem Ipsum", LongDescription = "A lacquerware statue first released for sale at the Magnificent Irodori Festival. It is based on Inazuma's most distinguished Almighty Shogun, and is designed by Yae Publishing House's top artist and handcrafted by the most skilled lacquerware master in Inazuma City, with excellent workmanship. When one considers this in addition to the mere 300 available at first launch, and the limit on purchases to one per customer, it seems little surprise that there would be a mad rush to purchase one.", Category = Categories["Figures"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\NarukamiOgoshoGodOfThunder.png", InStock = true, IsTopFigPick = true, ImageThumbnailUrl = "Images/figurines/NarukamiOgoshoGodOfThunder.png" },
                    new  Fig { Name = "Strike Freedom Gundam Kit", Price = 18.95M, ShortDescription = "Lorem Ipsum", LongDescription = "Introducing a High Grade kit of the new Mighty Strike Freedom Gundam from the movie “Mobile Suit Gundam SEED Freedom”!Recreate iconic action poses from the movie with the specialized internal structure of the “SEED Action System.” The individual hip joint connections in both legs allow for upward and downward swinging, enabling you to achieve dynamic and precise posing.Features a Real Metallic Gloss Injection material for the gold parts, enhancing their metallic luster.The wings have extensive individual articulation and can recreate expanded configurations. The white wings have 8 sliding joints for replicating the deployed state.For added realism, 3D metallic stickers are included for a luminous effect. The blade parts of the included “Futsunomitama” sword showcase different textures with two surface finishes.The “Proud Defender” can be removed and displayed separately, and you can recreate the forehead cannon’s deployed state through part replacement. The hip rail gun can be extended to replicate a simultaneous firing position.Comes with an array of armaments, including beam sabers, beam shields, and even a grip for replicating connected beam saber states.", Category = Categories["Gunpla"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\gunpla\\StrikeFreedom.jpg", InStock = true, IsTopFigPick = true, ImageThumbnailUrl = "Images/gunpla/StrikeFreedom.jpg" },
                    new  Fig { Name = "Xiao Figurine", Price = 15.95M, ShortDescription = "Lorem Ipsum", LongDescription = "The Xiao Figure proudly stands at approximately 27 centimeters. Poised elegantly atop a cluster of fragmented stones, the Vigilant Yaksha reveals a determined youthful face beneath the traditional Nuo mask. The character's features are further accentuated by detailed highlights in his hair, mystical beast patterns on his arm, and precise paintwork. The sharp gleam of the demon-slaying vajra around his neck, the polished reflection on the armored boots, the metallic allure of the incense burner pendant, and the meticulous gradient and shadows on his gloves and attire showcase a perfect blend of utilitarian and grand design. Enhanced by transparent components, Xiao's jadeite accessories gleam with clarity. His Anemo Vision sparkles, and the Primordial Jade Winged-Spear he wields is resplendent, faithfully reproducing every intricate detail from the game. The figure's base is intricately adorned with transparent motifs, enveloped in a miasmic aura, emphasizing the spear's dramatic descent, capturing the essence of the mighty Bane of All Evil.", Category = Categories["Figures"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\XiaoFig.png", InStock = true, IsTopFigPick = true, ImageThumbnailUrl = "Images/figurines/XiaoFig.png" },
                    new  Fig { Name = "Xiao Decorative Vinyl", Price = 12.95M, ShortDescription = "Lorem Ipsum", LongDescription = "Genshin Impact Xiao Acrylic Stand, Genshin Xiao Action Figure Standee Desk Stand, Genshin Impact Gift, Birthday gift", Category = Categories["Vinyls"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\vinyls\\XiaoVinyl.png", InStock = true, IsTopFigPick = true, ImageThumbnailUrl = "Images/vinyls/XiaoVinyl.png" },
                    new  Fig { Name = "Nu Gundam Kit", Price = 29.95M, ShortDescription = "Lorem Ipsum", LongDescription = "The Entry Grade of the Nu Gundam is finally here! It possesses a wide range of articulation, so after a simple assembly you’ll be able to create your very own unique Gunpla display! Order now!", Category = Categories["Gunpla"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\gunpla\\NuGundam.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/gunpla/NuGundam.png"   },
                    new  Fig { Name = "Jing Yuan Figurine", Price = 12.95M, ShortDescription = "Lorem Ipsum", LongDescription = "One of the seven Arbiter-Generals of the Xianzhou Alliance's Cloud Knights, and one of the Six Charioteers of the Xianzhou Luofu. Although he appears lazy, Jing Yuan has been a general on the Luofu for centuries, an amount of time exceeding most of his peers. This can be attributed to his wisdom and attention to routine measures, with Jing Yuan preferring to be preventive rather than corrective. ", Category = Categories["Figures"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\JingYuan.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/figurines/JingYuan.png"   },
                    new  Fig { Name = "Blade Decorative Vinyl", Price = 18.95M, ShortDescription = "Lorem Ipsum", LongDescription = "A member of the Stellaron Hunters and a swordsman who abandoned his body to become a blade. He pledges loyalty to Destiny's Slave and possesses a terrifying self-healing ability. ", Category = Categories["Vinyls"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\vinyls\\BladeVinyl.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/vinyls/BladeVinyl.png",   },
                    new  Fig { Name = "Kafka Figurine", Price = 18.95M, ShortDescription = "Lorem Ipsum", LongDescription = "A member of the Stellaron Hunters who is calm, collected, and beautiful. Her record on the wanted list of the Interastral Peace Corporation only lists her name and her hobby. People have always imagined her to be elegant, respectable, and in pursuit of things of beauty even in combat. ", Category = Categories["Figures"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\KafkaFig.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/figurines/KafkaFig.png"   },
                    new  Fig { Name = "RX-78-2 Gundam Kit", Price = 15.95M, ShortDescription = "Lorem Ipsum", LongDescription = "The RX-78-2 Gundam is the titular mobile suit of Mobile Suit Gundam television series. Part of the RX-78 Gundam series, it was built in secret on Side 7. The Gundam would turn the tide of war in favor of the Earth Federation during the One Year War against the Principality of Zeon. It was primarily piloted by Amuro Ray. ", Category = Categories["Gunpla"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\gunpla\\Gundam.jpg", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/gunpla/Gundam.jpg"   },
                    new  Fig { Name = "Blade Figurine", Price = 13.95M, ShortDescription = "Lorem Ipsum", LongDescription = "A member of the Stellaron Hunters and a swordsman who abandoned his body to become a blade. He pledges loyalty to Destiny's Slave and possesses a terrifying self-healing ability. ", Category = Categories["Figurine"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\BladeFig.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/figurines/BladeFig.png"   },
                    new  Fig { Name = "Furina Decorative Vinyl", Price = 17.95M, ShortDescription = "Lorem Ipsum", LongDescription = "Introduced as the flamboyant and overconfident Hydro Archon, Furina's theatrics are eventually revealed to be a public persona, which she later discards in favor of living a relatively humbler life as an actress and artistic consultant. ", Category = Categories["Vinyls"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\vinyls\\FurinaVinyl.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/vinyls/FurinaVinyl.png"   },
                    new  Fig { Name = "Cloud Play Arts Kai Figure", Price = 15.95M, ShortDescription = "Lorem Ipsum", LongDescription = "From “FINAL FANTASY VII REMAKE”, the brand new Play Arts Kai Action Figure is based on Cloud Strife's model from the actual game itself!Generated from the characters 3D model, this newly created mould reproduces high-quality character features, figrced ears to the delicate coloured eyes, this figure of Cloud showcases incredible detail.And that's not all, even the famous Buster Sword has been weathered with scratches and rust to showcase the reality of many fierce battles! ", Category = Categories["Figures"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\CloudFig.jpeg", InStock = false, IsTopFigPick = false, ImageThumbnailUrl = "Images/figurines/CloudFig.jpeg"   },
                    new  Fig { Name = "Dainsleif Decorative Vinyl", Price = 12.95M, ShortDescription = "Lorem Ipsum", LongDescription = "Dainsleif is the former knight captain of the Royal Guard of Khaenri'ah. However, he failed to prevent the destruction of Khaenri'ah 500 years ago. A curse of immortality was placed upon him so that he would forever wander Teyvat. ", Category = Categories["Vinyls"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\vinyls\\DainsleifVinyl.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/vinyls/DainsleifVinyl.png"   },
                    new  Fig { Name = "ZZ Gundam Kit", Price = 15.95M, ShortDescription = "Lorem Ipsum", LongDescription = "ZZ Gundam makes the move to HGUC! To preserve the outstanding detail and proportions, transforming is accomplished via interchangeable parts. The ‘Double-Zeta’ can be transformed between Core Fighter, Core Top, Core Base, and G Fortress modes. As part of its arsenal, the ZZ Gundam features a Double Beam Rifle, two Hyper Beam Sabers, and Missile Pods. When displaying it in G Fortress Mode, part of the frame is used as a base. This figce also holds parts which are not used when in certain modes. Foil stickers are also provided. ", Category = Categories["Gunpla"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\gunpla\\ZZGundam.jpg", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/gunpla/ZZGundam.jpg"   },
                    new  Fig { Name = "Dan Heng Decorative Vinyl", Price = 15.95M, ShortDescription = "Lorem Ipsum", LongDescription = "The cold and reserved train guard and archivist of the Astral Express. Wielding a spear named Cloud-Piercer, he joined the Express crew to escape his secluded past. ", Category = Categories["Vinyls"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\vinyls\\DanHengVinyl.png", InStock = true, IsTopFigPick = false, ImageThumbnailUrl = "Images/vinyls/DanHengVinyl.png"   },
                    new  Fig { Name = "Satoru Gojo Figurine", Price = 18.95M, ShortDescription = "Lorem Ipsum", LongDescription = "Jujutsu Kaisen SPM Figure \"Satoru Gojo\" Hollow Purple (Kyoshiki \"Murasaki\") from Sega. ", Category = Categories["Figures"], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\Gojo.jpg", InStock = false, IsTopFigPick = false, ImageThumbnailUrl = "Images/figurines/Gojo.jpg"   }
                );
            }

            context.SaveChanges();
        }

        private static Dictionary<string, Category>? categories;

        public static Dictionary<string, Category> Categories
        {
            get
            {
                if (categories == null)
                {
                    var genresList = new Category[]
                    {
                        new Category { CategoryName = "Figures" },
                        new Category { CategoryName = "Gunpla" },
                        new Category { CategoryName = "Vinyls" }
                    };

                    categories = new Dictionary<string, Category>();

                    foreach (Category genre in genresList)
                    {
                        categories.Add(genre.CategoryName, genre);
                    }
                }

                return categories;
            }
        }
    }
}
