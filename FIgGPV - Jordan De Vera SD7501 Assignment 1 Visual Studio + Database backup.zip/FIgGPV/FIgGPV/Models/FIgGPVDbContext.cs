﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Internal;

namespace FIgGPV.Models
{
    public class FIgGPVDbContext : DbContext
    {
        public FIgGPVDbContext(DbContextOptions<FIgGPVDbContext> options) : base(options) 
        {
        
        }

        public DbSet<Category> Categories { get; set; }
        public DbSet<Fig> Figs { get; set; }

        public DbSet<ShoppingCartItem> ShoppingCartItems { get; set;}
    }
}
