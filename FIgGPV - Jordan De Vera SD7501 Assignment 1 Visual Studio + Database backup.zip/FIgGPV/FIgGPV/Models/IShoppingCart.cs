﻿using System.IO.Pipelines;

namespace FIgGPV.Models
{
    public interface IShoppingCart
    {
        void AddToCart(Fig fig);
        int RemoveFromCart(Fig fig);
        List<ShoppingCartItem> GetShoppingCartItems();
        void ClearCart();
        decimal GetShoppingCartTotal();
        List<ShoppingCartItem> ShoppingCartItems { get; set; }
    }
}
