﻿using FIgGPV.Models;
using System.IO.Pipelines;

namespace FIgGPV.Models
{
    public class MockFigRepository : IFigRepository
    {
        private readonly ICategoryRepository _categoryRepository = new MockCategoryRepository();

        public IEnumerable<Fig> AllFigs =>
            new List<Fig>
            {
                new Fig {FigId = 1, Name="Statue of Her Excellency, Narukami Ogosho God of Thunder", Price=15.95M, ShortDescription="Lorem Ipsum", LongDescription="A lacquerware statue first released for sale at the Magnificent Irodori Festival. It is based on Inazuma's most distinguished Almighty Shogun, and is designed by Yae Publishing House's top artist and handcrafted by the most skilled lacquerware master in Inazuma City, with excellent workmanship. When one considers this in addition to the mere 300 available at first launch, and the limit on purchases to one per customer, it seems little surprise that there would be a mad rush to purchase one.", Category = _categoryRepository.AllCategories.ToList()[0],ImageUrl="C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\NarukamiOgoshoGodOfThunder.png", InStock=true, IsTopFigPick=false, ImageThumbnailUrl="Images/figurines/NarukamiOgoshoGodOfThunder.png"},

                new Fig {FigId = 2, Name="Strike Freedom Gundam Kit", Price=18.95M, ShortDescription="Lorem Ipsum", LongDescription="Introducing a High Grade kit of the new Mighty Strike Freedom Gundam from the movie “Mobile Suit Gundam SEED Freedom”!Recreate iconic action poses from the movie with the specialized internal structure of the “SEED Action System.” The individual hip joint connections in both legs allow for upward and downward swinging, enabling you to achieve dynamic and precise posing.Features a Real Metallic Gloss Injection material for the gold parts, enhancing their metallic luster.The wings have extensive individual articulation and can recreate expanded configurations. The white wings have 8 sliding joints for replicating the deployed state.For added realism, 3D metallic stickers are included for a luminous effect. The blade parts of the included “Futsunomitama” sword showcase different textures with two surface finishes.The “Proud Defender” can be removed and displayed separately, and you can recreate the forehead cannon’s deployed state through part replacement. The hip rail gun can be extended to replicate a simultaneous firing position.Comes with an array of armaments, including beam sabers, beam shields, and even a grip for replicating connected beam saber states.", Category = _categoryRepository.AllCategories.ToList()[1],ImageUrl="C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\gunpla\\StrikeFreedom.jpg", InStock=true, IsTopFigPick=false, ImageThumbnailUrl="Images/gunpla/StrikeFreedom.jpg"},
                new Fig { FigId = 3, Name = "Xiao Figurine", Price = 15.95M, ShortDescription = "Lorem Ipsum", LongDescription = "The Xiao Figure proudly stands at approximately 27 centimeters. Poised elegantly atop a cluster of fragmented stones, the Vigilant Yaksha reveals a determined youthful face beneath the traditional Nuo mask. The character's features are further accentuated by detailed highlights in his hair, mystical beast patterns on his arm, and precise paintwork. The sharp gleam of the demon-slaying vajra around his neck, the polished reflection on the armored boots, the metallic allure of the incense burner pendant, and the meticulous gradient and shadows on his gloves and attire showcase a perfect blend of utilitarian and grand design. Enhanced by transparent components, Xiao's jadeite accessories gleam with clarity. His Anemo Vision sparkles, and the Primordial Jade Winged-Spear he wields is resplendent, faithfully reproducing every intricate detail from the game. The figure's base is intricately adorned with transparent motifs, enveloped in a miasmic aura, emphasizing the spear's dramatic descent, capturing the essence of the mighty Bane of All Evi.", Category = _categoryRepository.AllCategories.ToList()[0], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\figurines\\XiaoFig.png", InStock = true, IsTopFigPick = true, ImageThumbnailUrl = "Images/figurines/XiaoFig.png" },
                new Fig { FigId = 4, Name = "Xiao Decorative Vinyl", Price = 12.95M, ShortDescription = "Lorem Ipsum", LongDescription = "Genshin Impact Xiao Acrylic Stand, Genshin Xiao Action Figure Standee Desk Stand, Genshin Impact Gift, Birthday gift", Category = _categoryRepository.AllCategories.ToList()[2], ImageUrl = "C:\\Users\\Jordan\\source\\repos\\SD7501\\Assignment1\\FIgGPV\\FIgGPV\\wwwroot\\Images\\vinyls\\XiaoVinyl.png", InStock = true, IsTopFigPick = true, ImageThumbnailUrl = "Images/Vinyls/XiaoVinyl.png" },
            };

        public IEnumerable<Fig> TopFigs
        {
            get
            {
                return AllFigs.Where(p => p.IsTopFigPick);
            }
        }

        public Fig? GetFigById(int figId) => AllFigs.FirstOrDefault(p => p.FigId == figId);

        public IEnumerable<Fig> SearchFigs(string searchQuery)
        {
            throw new NotImplementedException();
        }
    }
}
