﻿namespace FIgGPV.Models
{
    public class CategoryRepository :ICategoryRepository
    {
        private readonly FIgGPVDbContext _figgpvDbContext;


        public CategoryRepository(FIgGPVDbContext figgpvDbContext)
        {
            _figgpvDbContext = figgpvDbContext;
        }

        public IEnumerable<Category> AllCategories => _figgpvDbContext.Categories.OrderBy(p => p.CategoryName);
    }
}

