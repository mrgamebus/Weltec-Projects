﻿namespace FIgGPV.Models
{
    public class MockCategoryRepository : ICategoryRepository
    {
        public IEnumerable<Category> AllCategories =>
    new List<Category>
    {
                new Category{CategoryId=1, CategoryName="Figures", Description="Figurines"},
                new Category{CategoryId=2, CategoryName="Gunpla", Description="Gundam Model Kits"},
                new Category{CategoryId=3, CategoryName="Vinyls", Description="Vinyl Decorative Stands"}
    };
    }
}
