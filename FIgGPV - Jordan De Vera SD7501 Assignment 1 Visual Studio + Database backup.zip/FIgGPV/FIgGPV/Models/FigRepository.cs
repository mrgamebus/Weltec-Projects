﻿using Microsoft.EntityFrameworkCore;
using System.IO.Pipelines;

namespace FIgGPV.Models
{
    public class FigRepository : IFigRepository

    {
        private readonly FIgGPVDbContext _figgpvDbContext;

        public FigRepository(FIgGPVDbContext figgpvdbContext)
        {
            _figgpvDbContext = figgpvdbContext;
        }

        public IEnumerable<Fig> AllFigs
        {
            get
            {
                return _figgpvDbContext.Figs.Include(c => c.Category);
            }
        }

        public IEnumerable<Fig> TopFigs
        {
            get
            {
                return _figgpvDbContext.Figs.Include(c => c.Category).Where(p => p.IsTopFigPick);
            }
        }

        public Fig? GetFigById(int figId)
        {
            return _figgpvDbContext.Figs.FirstOrDefault(p => p.FigId == figId);
        }

        public IEnumerable<Fig> SearchFigs(string searchQuery)
        {
            throw new NotImplementedException();
        }
    }
}
