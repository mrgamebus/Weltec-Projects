﻿using System.IO.Pipelines;
using Microsoft.EntityFrameworkCore;


namespace FIgGPV.Models
{
    public class ShoppingCart : IShoppingCart
    {
        private readonly FIgGPVDbContext _figgpvDbContext;

        public ShoppingCart(FIgGPVDbContext figgpvDbContext)
        {
            _figgpvDbContext = figgpvDbContext;
        }

        public List<ShoppingCartItem> ShoppingCartItems { get; set; } = default!;
        public String? ShoppingCartId;


        public static ShoppingCart GetCart(IServiceProvider services)
        {

            ISession? session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext?.Session;
            FIgGPVDbContext context = services.GetService<FIgGPVDbContext>() ?? throw new Exception("Error initializing");
            string cartId = session?.GetString("CartId") ?? Guid.NewGuid().ToString();
            session?.SetString("CartId", cartId);
            return new ShoppingCart(context) { ShoppingCartId = cartId };
        }


        public void AddToCart(Fig fig)
        {
            var shoppingCartItem =
            _figgpvDbContext.ShoppingCartItems.SingleOrDefault(
            s => s.Fig.FigId == fig.FigId && s.ShoppingCartId == ShoppingCartId);
            if (shoppingCartItem == null)
            {
                shoppingCartItem = new ShoppingCartItem
                {
                    ShoppingCartId = ShoppingCartId,
                    Fig = fig,
                    Amount = 1
                };
                _figgpvDbContext.ShoppingCartItems.Add(shoppingCartItem);
            }
            else
            {

                shoppingCartItem.Amount++;
            }

            _figgpvDbContext.SaveChanges();
        }

        public int RemoveFromCart(Fig fig)
        {
            var shoppingCartItem =
                _figgpvDbContext.ShoppingCartItems.SingleOrDefault(
                    s => s.Fig.FigId == fig.FigId && s.ShoppingCartId == ShoppingCartId);
            var localAmount = 0;
            if (shoppingCartItem != null)
            {
                if (shoppingCartItem.Amount > 1)
                {
                    shoppingCartItem.Amount--;
                    localAmount = shoppingCartItem.Amount;
                }
                else
                {
                    _figgpvDbContext.ShoppingCartItems.Remove(shoppingCartItem);
                }

                _figgpvDbContext.SaveChanges();
            }

            return localAmount;
        }


        public List<ShoppingCartItem> GetShoppingCartItems()
        {
            return ShoppingCartItems ??=
            _figgpvDbContext.ShoppingCartItems.Where(c => c.ShoppingCartId ==
            ShoppingCartId)
            .Include(s => s.Fig)
            .ToList();

        }


        public void ClearCart()
        {
            var cartItems = _figgpvDbContext
            .ShoppingCartItems
            .Where(cart => cart.ShoppingCartId == ShoppingCartId);
            _figgpvDbContext.ShoppingCartItems.RemoveRange(cartItems);
            _figgpvDbContext.SaveChanges();
        }


        public decimal GetShoppingCartTotal()
        {
            var total = _figgpvDbContext.ShoppingCartItems.Where(c => c.ShoppingCartId == ShoppingCartId)
                .Select(c => c.Fig.Price * c.Amount).Sum();
            return total;
        }
    }
}
