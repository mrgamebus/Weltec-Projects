﻿using System.IO.Pipelines;

namespace FIgGPV.Models
{
    public interface IFigRepository
    {
        IEnumerable<Fig> AllFigs { get; }

        IEnumerable<Fig> TopFigs { get; }
       
        Fig? GetFigById(int FigId);
       IEnumerable<Fig> SearchFigs(string searchQuery);
    }
}
