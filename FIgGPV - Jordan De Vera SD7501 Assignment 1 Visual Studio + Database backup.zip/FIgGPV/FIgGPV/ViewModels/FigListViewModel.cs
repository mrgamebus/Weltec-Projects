﻿using FIgGPV.Models;

namespace FIgGPV.ViewModels
{
    public class FigListViewModel
    {
        public IEnumerable<Fig> Figs { get; set; }

        public string? CurrentCategory { get; set; }

        public FigListViewModel(IEnumerable<Fig> figs, string? currentCategory)
        {
            Figs = figs;
            CurrentCategory = currentCategory;
        }
    }
}
