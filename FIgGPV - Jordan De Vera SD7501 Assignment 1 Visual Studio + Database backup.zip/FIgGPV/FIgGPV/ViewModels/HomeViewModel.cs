﻿using System.IO.Pipelines;
using FIgGPV.Models;

namespace FIgGPV.ViewModels
{
    public class HomeViewModel
    {
        public IEnumerable<Fig> TopFigs { get; }
        public HomeViewModel(IEnumerable<Fig> topFigs)
        {
            TopFigs = topFigs;
        }
    }
}
