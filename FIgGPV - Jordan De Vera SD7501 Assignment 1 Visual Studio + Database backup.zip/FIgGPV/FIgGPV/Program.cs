using FIgGPV.Components;
using FIgGPV.Models;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddScoped<ICategoryRepository, CategoryRepository>();
builder.Services.AddScoped<IFigRepository, FigRepository>();

builder.Services.AddScoped<ShoppingCartSummary>();


builder.Services.AddScoped<IShoppingCart, ShoppingCart>(sp => ShoppingCart.GetCart(sp));
builder.Services.AddSession();
builder.Services.AddHttpContextAccessor();

builder.Services.AddDbContext<FIgGPVDbContext>(options =>
    {
        options.UseSqlServer(
            builder.Configuration["ConnectionStrings:FIgGPVDbContextConnection"]);
    });

var app = builder.Build();



if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

app.UseStaticFiles();
app.UseSession();

app.MapDefaultControllerRoute();
app.MapControllerRoute(
name: "default",
pattern: "{controller=Home}/{action=Index}/{id:int?}");


DbInitializer.Seed(app);

app.Run();
